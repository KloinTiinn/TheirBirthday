#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPlainTextEdit>
#include <QSettings>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

protected:
    void timerEvent(QTimerEvent *);

private slots:
    void on_actionColor_triggered();

    void on_actionFont_triggered();

private:
    Ui::MainWindow *ui;
    void refreshWindows();
    void setLst(QString);
    void setLstEvents();
    void setLstDates();
    QString getResultStr(QList<QString>, int pdays);
    QString getResultTodayStr(QList<QString>);
    QString getResultYesterdayStr(QList<QString>);
    QString getResultTomorrowStr(QList<QString>);
    void findTodayStrs(QPlainTextEdit *);
    QList<QString> qlEvents;
    QList<QString> qlDates;
    QList<QString> qlToday;
    QString gFileName;
    QColor gColor;
    QSettings settings;
};

#endif // MAINWINDOW_H
