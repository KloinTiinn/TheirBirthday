#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTextCodec>
#include <QDate>
#include <QDebug>
#include <QFileInfo>
#include <QColorDialog>
#include <QFontDialog>
#include <QSettings>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->actionExit, SIGNAL(triggered()), this, SLOT(close()));
    gColor = QColor(Qt::green).lighter(125);
    setLstEvents();
    setLstDates();

    QCoreApplication::setOrganizationName("Datasoft");
    QCoreApplication::setApplicationName("TheirBirthday");
    QSettings settings("Datasoft","TheirBirthday");

    int r = settings.value("/Red", 0).toInt();
    int g = settings.value("/Green", 0).toInt();
    int b = settings.value("/Blue", 0).toInt();

    if (r != 0 || g != 0 || b != 0)
        gColor = QColor::fromRgb(r, g, b);

    refreshWindows();
    startTimer(60000);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setLst(QString sFileName)
{
    QRegExp regexp("^[0-9][0-9]/[0-9][0-9]/[0-9][0-9][0-9][0-9]");

    QString myFileName = QCoreApplication::arguments().at(0);
    QFileInfo gfi(myFileName);
    QString sPath = myFileName.replace(gfi.fileName(), "");

    QFile fl(sPath + sFileName);
    if (!QFile::exists(sPath + sFileName))
    {
        fl.open(QIODevice::WriteOnly | QIODevice::Append);
        fl.close();
    }

    if (fl.open(QIODevice::ReadOnly))
    {
        QTextCodec *codec = QTextCodec::codecForName("CP1251");
        while(!fl.atEnd())
        {
            QByteArray sBStr = fl.readLine();
            QString sStr = codec->toUnicode(sBStr);

            if (sStr.contains(regexp))
            {
                if (sFileName == "events.txt")
                    qlEvents << sStr;
                else
                    qlDates << sStr;
            }
        }
        fl.close();
    }
}

void MainWindow::setLstEvents()
{
    setLst("events.txt");
}

void MainWindow::setLstDates()
{
    setLst("dates.txt");
}
//формируем строки "Вчера"
QString MainWindow::getResultYesterdayStr(QList<QString> pql)
{
    QString sb = "";
    foreach(QString fs, pql)
    {
        QString sDate = fs.left(10);
        QDate dDate = QDate::fromString(sDate, "dd/MM/yyyy");
        if (dDate.day() == QDate::currentDate().addDays(-1).day() && dDate.month() == QDate::currentDate().addDays(-1).month())
            sb += "Вчера" + fs.replace(sDate, "");// + "\n";
    }
    return sb;
}
//формируем строки "Сегодня"
QString MainWindow::getResultTodayStr(QList<QString> pql)
{
    QString sb = "";
    foreach(QString fs, pql)
    {
        QString sDate = fs.left(10);
        QDate dDate = QDate::fromString(sDate, "dd/MM/yyyy");
        if (dDate.day() == QDate::currentDate().day() && dDate.month() == QDate::currentDate().month())
        {
            int iy = QDate::currentDate().year() - dDate.year();
            if (iy > 0)
            {
                sb += "Сегодня " + fs.replace(sDate, "").trimmed() + " (" + QString::number(iy) + " годовщина)\n";
                qlToday.append("Сегодня " + fs.replace(sDate, "").trimmed() + " (" + QString::number(iy) + " годовщина)");
            }
            else
            {
                sb += "Сегодня " + fs.replace(sDate, "");
                qlToday.append("Сегодня " + fs.replace(sDate, "").trimmed());
            }
        }
    }
    return sb;
}
//формируем строки "Завтра"
QString MainWindow::getResultTomorrowStr(QList<QString> pql)
{
    QString sb = "";
    foreach(QString fs, pql)
    {
        QString sDate = fs.left(10);
        QDate dDate = QDate::fromString(sDate, "dd/MM/yyyy");
        if (dDate.day() == QDate::currentDate().addDays(1).day() && dDate.month() == QDate::currentDate().addDays(1).month())
        {
            int iy = QDate::currentDate().year() - dDate.year();
            if (iy > 0)
                sb += "Завтра " + fs.replace(sDate, "").trimmed() + " (" + QString::number(iy) + " годовщина)\n";
            else
                sb += "Завтра " + fs.replace(sDate, "");
        }
    }
    return sb;
}

//формируем строки "Через N дней"
QString MainWindow::getResultStr(QList<QString> pql, int pdays)
{
    if (pdays == -1)
        return getResultYesterdayStr(pql);
    if (pdays == 0)
        return getResultTodayStr(pql);
    if (pdays == 1)
        return getResultTomorrowStr(pql);
    QString sb = "";
    foreach(QString fs, pql)
    {
        QString sDate = fs.left(10);
        QDate dDate = QDate::fromString(sDate, "dd/MM/yyyy");
        if (dDate.day() == QDate::currentDate().addDays(pdays).day() && dDate.month() == QDate::currentDate().addDays(pdays).month())
        {
            int iy = QDate::currentDate().year() - dDate.year();
            if (iy > 0)
                sb += "Через " + QString::number(pdays) + (pdays>4?" дней (":" дня (") + sDate.left(5).replace("/", ".") + ") " + fs.replace(sDate, "").trimmed() + " (" + QString::number(iy) + " годовщина)\n";
            else
                sb += "Через " + QString::number(pdays) + (pdays>4?" дней (":" дня (") + sDate.left(5).replace("/", ".") + ") " + fs.replace(sDate, "");
        }
    }
    return sb;
}
//Подсвечиваем цветом сегодняшнее
void MainWindow::findTodayStrs(QPlainTextEdit *pte)
{
    pte->moveCursor(QTextCursor::Start);

    QTextCursor cur = ui->plainTEditEvents->textCursor();;
    QList<QTextEdit::ExtraSelection> lSel;

    QTextCursor findCur;

    foreach(QString fs, qlToday)
    {
        findCur = pte->document()->find(fs, cur);
        if(findCur != cur)
        {
            QTextEdit::ExtraSelection xtra;
            xtra.format.setBackground(gColor);
            xtra.cursor = findCur;
            lSel.append(xtra);
            pte->setExtraSelections(lSel);
        }
        cur = findCur;
    }
}

void MainWindow::refreshWindows()
{
    ui->plainTEditEvents->setPlainText("");
    ui->plainTEditDates->setPlainText("");

    QString sbEv = "", sbDt = "";

    for(int i = -1; i < 14; i++)
        sbDt += getResultStr(qlDates, i);

    for(int i = -1; i < 14; i++)
        sbEv += getResultStr(qlEvents, i);

    ui->plainTEditEvents->setPlainText(sbEv);
    ui->plainTEditDates->setPlainText(sbDt);

    findTodayStrs(ui->plainTEditEvents);
    findTodayStrs(ui->plainTEditDates);
}
//Выбор цвета
void MainWindow::on_actionColor_triggered()
{
    QColor tempColor = QColorDialog::getColor(gColor);
    if (tempColor.isValid())
    {
        gColor = tempColor;
        settings.setValue("/Red", tempColor.red());
        settings.setValue("/Green", tempColor.green());
        settings.setValue("/Blue", tempColor.blue());

        refreshWindows();
    }
}

void MainWindow::on_actionFont_triggered()
{
    bool bOk;
    QFont fnt = QFontDialog::getFont(&bOk);
    if (bOk)
    {
        ui->plainTEditDates->setFont(fnt);
        ui->plainTEditEvents->setFont(fnt);
    }
}

void MainWindow::timerEvent(QTimerEvent *)
{
    refreshWindows();
}
